# Planejamento e criação de Site .
Projeto de criação de Inbound Marketing Flow (Post de Blog), email marketing.
Utilização de  CSS e HTML.